// 5: Kasztelewicz (302858), Szczerba (302924), Gorecki (302847)
#include <factory.hpp>

void Factory::remove_worker(ElementID id){

    auto ptr = find_worker_by_id(id);
    IPackageReceiver *buff = &(*ptr);
    remove_receiver(w_list, id);

    for(auto& elem : w_list){
        for(auto& elem_prefs : elem.receiver_preferences_){
            if(elem_prefs.first == buff){
                elem.receiver_preferences_.remove_receiver(elem_prefs.first);
                break;
            }
        }
    }

    for(auto& elem : r_list){
        for(auto& elem_prefs : elem.receiver_preferences_){
            if(elem_prefs.first == buff){
                elem.receiver_preferences_.remove_receiver(elem_prefs.first);
                break;
            }
        }
    }
}

void Factory::remove_storehouse(ElementID id){

    auto ptr = find_worker_by_id(id);
    IPackageReceiver *buff = &(*ptr);
    remove_receiver(s_list, id);

    for(auto& elem : w_list){
        for(auto& elem_prefs : elem.receiver_preferences_){
            if(elem_prefs.first == buff){
                elem.receiver_preferences_.remove_receiver(elem_prefs.first);
                break;
            }
        }
    }
}


void Factory::do_package_passing() {
    for(auto& idx : r_list) idx.send_package();
    for(auto& idx : w_list) idx.send_package();
}


bool end_in_storehouse(const PackageSender* sender, std::map<const PackageSender*, NodeColor>& colors_map){

    if(colors_map[sender] == NodeColor::VERIFIED) return true;

    colors_map[sender] = NodeColor::VISITED;

    if(sender->receiver_preferences_.begin() == sender->receiver_preferences_.end()) throw DoesNotHaveReceivers();

    bool have_receiver = false;
    for(auto& receiver: sender->receiver_preferences_){
        if(receiver.first->get_receiver_type()==ReceiverType::STOREHOUSE) have_receiver = true;
        else if(receiver.first->get_receiver_type()==ReceiverType::WORKER){
            IPackageReceiver* receiver_ptr = receiver.first;
            auto worker_ptr = dynamic_cast<Worker*>(receiver_ptr);
            auto package_sender_ptr = dynamic_cast<PackageSender*>(worker_ptr);

            if(worker_ptr==sender) continue;
            have_receiver = true;
            if(colors_map[package_sender_ptr] == NodeColor::UNVISITED) end_in_storehouse(package_sender_ptr, colors_map);
        }
    }

    colors_map[sender] = NodeColor::VERIFIED;

    if(end_in_storehouse(sender, colors_map) && have_receiver) return true;
    else throw DoesNotHaveReceivers();
}

bool Factory::is_consistent() const{

    std::map<const PackageSender*, NodeColor> color;
    for(auto it = w_list.cbegin(); it!=w_list.cend(); it++){
        const PackageSender* r = &(*it);
        color[r] = NodeColor::UNVISITED;
    }
    for(auto it = r_list.cbegin(); it!=r_list.cend(); it++){
        const PackageSender* r = &(*it);
        color[r] = NodeColor::UNVISITED;
    }
    try {
        for(const auto& ramp: r_list) end_in_storehouse(&ramp, color);
    } catch(DoesNotHaveReceivers&){
        return false;
    }
    return true;
}

// 5: Kasztelewicz (302858), Szczerba (302924), Gorecki (302847)