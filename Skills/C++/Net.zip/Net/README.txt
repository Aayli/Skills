Największy projekt z c++, jaki zrobiłem, niestety nie jest w wersji finalnej, bo przedmiot już zaliczyłem,
a były inne egzaminy.