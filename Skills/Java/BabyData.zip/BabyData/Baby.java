
/**
 * Write a description of Baby here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import edu.duke.*;
import org.apache.commons.csv.*;
import java.io.*;

public class Baby {
    
    public void totalBirths(FileResource fr){
        int totalBirths = 0;
        int totalFemale = 0;
        int totalMale = 0;
        int totalFemaleNames = 0;
        int totalMaleNames = 0;
        for(CSVRecord line : fr.getCSVParser(false)){
            int numberOfChild = Integer.parseInt(line.get(2));
            totalBirths += numberOfChild;
            if(line.get(1).equals("F")){
                totalFemaleNames++;
                totalFemale += numberOfChild;
            }
            else{
                totalMaleNames++;
                totalFemale += numberOfChild;
            }
        }
        System.out.println("Total births: " + totalBirths);
        System.out.println("Total female names: " + totalFemaleNames);
        System.out.println("Total female: " + totalFemale);
        System.out.println("Total male names: " + totalMaleNames);
        
    }
    
    public int getRank(String name, String gender, FileResource fr){
        //FileResource fr = new FileResource("us_babynames_by_year/yob"+year+"short.csv");
        int count = 0;
        for(CSVRecord line : fr.getCSVParser(false)){
            if(line.get(1).equals(gender)){
                count++;
                if(line.get(0).equals(name)){
                    return count;
                }
            }
        }
        return -1;
    }
    
    public String getName(int rank, String gender, FileResource fr){
        //FileResource fr = new FileResource("us_babynames_by_year/yob"+year+"short.csv");
        int count = 0;
        for(CSVRecord line : fr.getCSVParser(false)){
            if(line.get(1).equals(gender)){
                count++;
                if(count == rank){
                    return line.get(0);
                }
            }
        }
        return "NO NAME";
    }
    
    public void whatIsNameInYear(String name, String gender, FileResource fr, FileResource newFr){
        int rank = getRank(name, gender, fr);
        String newName = getName(rank, gender, newFr);
        System.out.println( name + " would be " + newName);
    }
    
    public int yearOfHighestRank(String name, String gender, DirectoryResource dr){
        String yearOfHighestRank = "NAME NO EXIST";
        int bestRank = Integer.MAX_VALUE;
        for(File f : dr.selectedFiles()){
            FileResource fr = new FileResource(f);         
            int currentRank = getRank(name, gender, fr);
            if(currentRank != -1 && currentRank < bestRank){
                bestRank = currentRank;
                yearOfHighestRank = f.getName();
            }
        }
        if(yearOfHighestRank.equals("NAME NO EXIST")) {return -1;}
        yearOfHighestRank = yearOfHighestRank.substring(3,7);
        return Integer.parseInt(yearOfHighestRank);
    }
    
    public double getAverageRank(String name, String gender, DirectoryResource dr){
        double total = 0;
        int count = 0;
        for(File f : dr.selectedFiles()){
            FileResource fr = new FileResource(f);         
            int currentRank = getRank(name, gender, fr);
            if(currentRank == -1){
                return -1;
            }
            total += currentRank;
            count++;
        }
        return total/count;
    }
    
    public int getTotalBirthsRankedHigher(String name, String gender, FileResource fr){
        int totalBirths = 0;
        for(CSVRecord line : fr.getCSVParser(false)){
            int numberOfChild = Integer.parseInt(line.get(2));
            if(line.get(1).equals(gender)){
                if(line.get(0).equals(name)){
                    return totalBirths;
                }
                totalBirths += numberOfChild;
            }
        }
        return -1;
    }
    
    public void testTotalBirths(){
        totalBirths(new FileResource());
    }
    
    public void testGetRank(){
        System.out.println("Rank of name: " + getRank("Frank", "M", new FileResource()));
    }
    
    public void testGetName(){
        System.out.println("Name on rank: " + getName(450, "M", new FileResource()));
    }
    
    public void testWhatIsNameInYear(){
        whatIsNameInYear("Owen", "M", new FileResource(), new FileResource());
    }
    
    public void testYearOfHighestRank(){
        System.out.println("Year of Highest rank: " + yearOfHighestRank("Mich", "M", new DirectoryResource()));
    }
    
    public void testGetAverageRank(){
        System.out.println("Average rank: " + getAverageRank("Robert", "M", new DirectoryResource()));        
    }
    
    public void testGetTotalBirthsRankedHigher(){
        System.out.println("Child with more popular name: " + getTotalBirthsRankedHigher("", "M", new FileResource()));
    }
}
